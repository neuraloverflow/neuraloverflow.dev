---
layout: post
title:  "Efficient Pandas Tricks"
---

## What is Pandas?

If you don't know what is Pandas you can find the official documentation [here](https://pandas.pydata.org/pandas-docs/stable/getting_started/index.html) and a 10 minutes introduction [here](http://pandas.pydata.org/pandas-docs/stable/10min.html). If you haven't read at least the 10min intro, you should! It is very well written and gets you quickly up and running with the main .



## Now give me the TRICKS 👊!

Alright, here are some tricks divided by category.

###